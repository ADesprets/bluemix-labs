package com.ibm.ad.latency;

/**
 * Class that handles the various style used when creating the Workbook
 * @author desprets
 *
 */
public class StyleManager {

}
